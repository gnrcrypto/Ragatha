use anyhow::{Result};
use candle_core::Device;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use tokio::fs;
use tokio::sync::Mutex;

mod document;
mod embedding;
mod retriever;
mod memory;

pub use document::{Document, DocumentSource};
pub use embedding::{EmbeddingEngine, CachedEmbeddingEngine};
pub use retriever::Retriever;
pub use memory::PersistentMemory;

pub struct RagCore {
    documents: Arc<Mutex<Vec<Document>>>,
    embedding_engine: CachedEmbeddingEngine,
    retriever: Retriever,
    memory: PersistentMemory,
    task_context: Option<TaskContext>,
    main_model_path: PathBuf,
}

#[derive(Debug, Clone)]
pub struct TaskContext {
    pub task_description: String,
    pub entities: Vec<String>,
    pub libraries: Vec<String>,
    pub operations: Vec<String>,
    pub coverage: f32,
}

impl RagCore {
    pub async fn new(device: Device, main_model_path: PathBuf) -> Result<Self> {
        println!("🧠 Initializing Ragatha RAG Core...");
        
        let embedding_engine = CachedEmbeddingEngine::new(device.clone()).await?;
        println!("✅ Embedding engine initialized");
        println!("{}", embedding_engine.info());
        
        let is_compatible = embedding_engine.get_engine().verify_compatibility(&main_model_path).await?;
        if !is_compatible {
            println!("⚠️  Warning: Embedding model may not be fully compatible with main model");
        } else {
            println!("✅ Models verified for compatibility");
        }
        
        let retriever = Retriever::new();
        let memory = PersistentMemory::load().await?;
        
        Ok(Self {
            documents: Arc::new(Mutex::new(Vec::new())),
            embedding_engine,
            retriever,
            memory,
            task_context: None,
            main_model_path,
        })
    }
    
    pub async fn prepare_for_task(&mut self, task_description: &str, project_dir: &Path) -> Result<()> {
        println!("📚 Ragatha: Preparing RAG for task...");
        println!("Task: {}", task_description);
        println!("Project directory: {:?}", project_dir);
        
        let entities = self.extract_entities(task_description);
        let libraries = self.identify_libraries(&entities);
        let operations = self.identify_operations(&entities);
        
        println!("🔍 Entities identified: {:?}", entities);
        println!("📦 Libraries needed: {:?}", libraries);
        println!("⚙️  Operations needed: {:?}", operations);
        
        let mut documents = Vec::new();
        documents.extend(self.gather_readmes(project_dir).await?);
        documents.extend(self.gather_source_docs(project_dir).await?);
        documents.extend(self.gather_config_files(project_dir).await?);
        
        let model_readme = self.main_model_path.join("README.md");
        if model_readme.exists() {
            println!("📖 Found README in model directory");
            let content = fs::read_to_string(&model_readme).await?;
            documents.push(Document::new(
                content,
                DocumentSource::Readme(model_readme.display().to_string()),
            ));
        }
        
        if !libraries.is_empty() {
            documents.extend(self.gather_crate_docs(&libraries).await?);
        }
        
        if !operations.is_empty() {
            documents.extend(self.gather_system_docs(&operations).await?);
        }
        
        let coverage = self.calculate_coverage(&documents, &entities);
        println!("📊 Knowledge coverage: {:.1}%", coverage * 100.0);
        
        let mut final_docs = documents;
        if coverage < 0.7 {
            println!("🌐 Coverage insufficient, fetching online resources...");
            let online_docs = self.fetch_online_data(&entities, &libraries).await?;
            final_docs.extend(online_docs);
        }
        
        println!("🧠 Building embeddings for {} documents...", final_docs.len());
        let mut processed_docs = Vec::new();
        for doc in final_docs {
            let embedding = self.embedding_engine.embed(&doc.content).await?;
            processed_docs.push(doc.with_embedding(embedding));
        }
        
        let mut doc_store = self.documents.lock().await;
        *doc_store = processed_docs;
        self.retriever.index_documents(&doc_store).await?;
        
        self.task_context = Some(TaskContext {
            task_description: task_description.to_string(),
            entities,
            libraries,
            operations,
            coverage,
        });
        
        println!("✅ RAG preparation complete! Ready for task execution.");
        println!("📚 Documents indexed: {}", doc_store.len());
        
        Ok(())
    }
    
    pub async fn retrieve(&mut self, query: &str, top_k: usize) -> Result<Vec<Document>> {
        let query_embedding = self.embedding_engine.embed(query).await?;
        let docs = self.retriever.search(query_embedding, top_k).await?;
        Ok(docs)
    }
    
    pub async fn get_context_for_operation(&mut self, operation: &str) -> Result<String> {
        let docs = self.retrieve(operation, 3).await?;
        let context = docs
            .iter()
            .map(|d| format!("From {}:\n{}\n", d.source, d.content))
            .collect::<Vec<_>>()
            .join("\n");
        Ok(context)
    }
    
    pub async fn get_state_info(&self) -> String {
        let doc_count = self.documents.lock().await.len();
        format!(
            "RAG Core State:\n- Documents: {}\n- Embedding Cache: {}\n- Memory: {} tasks, {} patterns\n- Task Context: {}",
            doc_count,
            self.embedding_engine.info(),
            self.memory.task_history.len(),
            self.memory.learned_patterns.len(),
            if self.task_context.is_some() { "Active" } else { "None" }
        )
    }
    
    fn extract_entities(&self, task: &str) -> Vec<String> {
        let mut entities = Vec::new();
        let task_lower = task.to_lowercase();
        
        if task_lower.contains("read") || task_lower.contains("file") || task_lower.contains("open") {
            entities.push("file_io".to_string());
        }
        if task_lower.contains("write") || task_lower.contains("save") || task_lower.contains("create") {
            entities.push("file_write".to_string());
        }
        if task_lower.contains("network") || task_lower.contains("http") || task_lower.contains("socket") {
            entities.push("networking".to_string());
        }
        if task_lower.contains("process") || task_lower.contains("execute") || task_lower.contains("run") {
            entities.push("process_management".to_string());
        }
        if task_lower.contains("syscall") || task_lower.contains("system call") {
            entities.push("syscalls".to_string());
        }
        if task_lower.contains("capability") || task_lower.contains("bridge") {
            entities.push("capabilities".to_string());
        }
        if task_lower.contains("rag") || task_lower.contains("retrieval") {
            entities.push("rag_system".to_string());
        }
        
        entities
    }
    
    fn identify_libraries(&self, entities: &[String]) -> Vec<String> {
        let mut libraries: Vec<String> = Vec::new();
        let library_map = HashMap::from([
            ("candle_transformers", vec!["candle_transformers", "candle", "llm", "bert"]),
            ("tokio", vec!["tokio", "async"]),
            ("serde", vec!["serde", "json"]),
            ("reqwest", vec!["reqwest", "http", "api"]),
            ("anyhow", vec!["anyhow", "error"]),
            ("walkdir", vec!["walkdir", "directory"]),
        ]);
        
        for entity in entities {
            for (lib, keywords) in &library_map {
                if keywords.iter().any(|kw| entity.contains(kw)) {
                    let lib_str = (*lib).to_string();
                    if !libraries.contains(&lib_str) {
                        libraries.push(lib_str);
                    }
                }
            }
        }
        
        libraries
    }
    
    fn identify_operations(&self, entities: &[String]) -> Vec<String> {
        let mut operations: Vec<String> = Vec::new();
        let op_map = HashMap::from([
            ("read", vec!["read", "open", "file", "io"]),
            ("write", vec!["write", "save", "create"]),
            ("network", vec!["socket", "connect", "http"]),
            ("process", vec!["exec", "spawn", "process"]),
            ("syscall", vec!["syscall", "kernel"]),
        ]);
        
        for entity in entities {
            for (op, keywords) in &op_map {
                if keywords.iter().any(|kw| entity.contains(kw)) {
                    let op_str = (*op).to_string();
                    if !operations.contains(&op_str) {
                        operations.push(op_str);
                    }
                }
            }
        }
        
        operations
    }
    
    async fn gather_readmes(&self, dir: &Path) -> Result<Vec<Document>> {
        let mut docs = Vec::new();
        let patterns = ["README.md", "README.txt", "readme.md", "README"];
        
        for entry in walkdir::WalkDir::new(dir).max_depth(3).into_iter().filter_map(|e| e.ok()) {
            let path = entry.path();
            if let Some(name) = path.file_name().and_then(|n| n.to_str()) {
                if patterns.iter().any(|p| name.eq_ignore_ascii_case(p)) {
                    if let Ok(content) = fs::read_to_string(path).await {
                        docs.push(Document::new(content, DocumentSource::Readme(path.display().to_string())));
                        println!("   📄 Found README: {}", path.display());
                    }
                }
            }
        }
        Ok(docs)
    }
    
    async fn gather_source_docs(&self, dir: &Path) -> Result<Vec<Document>> {
        let mut docs = Vec::new();
        for entry in walkdir::WalkDir::new(dir).max_depth(3).into_iter().filter_map(|e| e.ok()) {
            let path = entry.path();
            if let Some(ext) = path.extension() {
                if ext == "rs" {
                    if let Ok(content) = fs::read_to_string(path).await {
                        let doc_comments: Vec<_> = content
                            .lines()
                            .filter(|line| line.trim().starts_with("///") || line.trim().starts_with("//!"))
                            .map(|line| line.trim_start_matches('/').trim().to_string())
                            .collect();
                        if !doc_comments.is_empty() {
                            docs.push(Document::new(
                                doc_comments.join("\n"),
                                DocumentSource::SourceDoc(path.display().to_string()),
                            ));
                        }
                    }
                }
            }
        }
        Ok(docs)
    }
    
    async fn gather_config_files(&self, dir: &Path) -> Result<Vec<Document>> {
        let mut docs = Vec::new();
        let config_files = ["Cargo.toml", "config.toml", "config.json", ".env"];
        for file in config_files {
            let path = dir.join(file);
            if path.exists() {
                if let Ok(content) = fs::read_to_string(&path).await {
                    docs.push(Document::new(content, DocumentSource::Config(path.display().to_string())));
                    println!("   ⚙️  Found config: {}", path.display());
                }
            }
        }
        Ok(docs)
    }
    
    async fn gather_crate_docs(&self, libraries: &[String]) -> Result<Vec<Document>> {
        let mut docs = Vec::new();
        let client = reqwest::Client::new();
        
        for lib in libraries {
            println!("📦 Gathering documentation for crate: {}", lib);
            let url = format!("https://crates.io/api/v1/crates/{}", lib);
            if let Ok(response) = client.get(&url).send().await {
                if let Ok(json) = response.json::<serde_json::Value>().await {
                    if let Some(description) = json["crate"]["description"].as_str() {
                        docs.push(Document::new(
                            format!("Crate: {}\nDescription: {}\n", lib, description),
                            DocumentSource::Online(format!("https://crates.io/crates/{}", lib)),
                        ));
                    }
                }
            }
        }
        Ok(docs)
    }
    
    async fn gather_system_docs(&self, operations: &[String]) -> Result<Vec<Document>> {
        let mut docs = Vec::new();
        for op in operations {
            println!("⚙️  Gathering documentation for syscall: {}", op);
            let man_cmd = format!("man -P cat {} 2>/dev/null", op);
            if let Ok(output) = tokio::process::Command::new("sh").arg("-c").arg(&man_cmd).output().await {
                if !output.stdout.is_empty() {
                    let content = String::from_utf8_lossy(&output.stdout);
                    docs.push(Document::new(content.to_string(), DocumentSource::SystemDoc(format!("man {}", op))));
                    println!("   📖 Found man page for: {}", op);
                }
            }
        }
        Ok(docs)
    }
    
    async fn fetch_online_data(&self, entities: &[String], _libraries: &[String]) -> Result<Vec<Document>> {
        let mut docs = Vec::new();
        let client = reqwest::Client::new();
        
        for entity in entities {
            let search_query = format!("Rust {} documentation tutorial", entity);
            let search_url = format!("https://api.duckduckgo.com/?q={}&format=json", search_query);
            if let Ok(response) = client.get(&search_url).send().await {
                if let Ok(json) = response.json::<serde_json::Value>().await {
                    if let Some(abstract_text) = json["Abstract"].as_str() {
                        if !abstract_text.is_empty() {
                            docs.push(Document::new(
                                abstract_text.to_string(),
                                DocumentSource::Online(format!("DDG search: {}", entity)),
                            ));
                            println!("   🌐 Found online data for: {}", entity);
                        }
                    }
                }
            }
        }
        Ok(docs)
    }
    
    fn calculate_coverage(&self, docs: &[Document], entities: &[String]) -> f32 {
        let total_entities = entities.len();
        if total_entities == 0 { return 1.0; }
        let mut covered = 0;
        let all_content = docs.iter().map(|d| d.content.to_lowercase()).collect::<Vec<_>>().join(" ");
        for entity in entities {
            if all_content.contains(&entity.to_lowercase()) { covered += 1; }
        }
        covered as f32 / total_entities as f32
    }
    
    pub async fn add_document(&mut self, content: String, source: DocumentSource) -> Result<()> {
        let embedding = self.embedding_engine.embed(&content).await?;
        let doc = Document::new(content, source).with_embedding(embedding);
        let mut docs = self.documents.lock().await;
        docs.push(doc);
        self.retriever.index_documents(&docs).await?;
        Ok(())
    }
    
    pub async fn get_all_documents(&self) -> Vec<Document> {
        self.documents.lock().await.clone()
    }
    
    pub async fn clear_knowledge_base(&mut self) -> Result<()> {
        let mut docs = self.documents.lock().await;
        docs.clear();
        self.retriever.clear().await?;
        Ok(())
    }
}

pub async fn init_rag(_project_dir: &Path, main_model_path: PathBuf, device: Device) -> Result<RagCore> {
    let mut rag = RagCore::new(device, main_model_path).await?;
    if let Err(e) = rag.memory.load_state().await {
        println!("⚠️  Could not load previous memory: {}", e);
    } else {
        println!("📖 Loaded previous knowledge from memory");
    }
    Ok(rag)
}
