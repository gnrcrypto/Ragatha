use anyhow::{Result};
use candle_core::{Device, DType};
use candle_nn::VarBuilder;
use std::path::{Path, PathBuf};
use tokio::fs;

// Simple config that matches our LFM2 embedding model
#[derive(Clone)]
pub struct EmbeddingConfig {
    pub vocab_size: usize,
    pub hidden_size: usize,
    pub num_hidden_layers: usize,
    pub num_attention_heads: usize,
    pub intermediate_size: usize,
    pub hidden_act: String,
    pub hidden_dropout_prob: f64,
    pub max_position_embeddings: usize,
    pub type_vocab_size: usize,
    pub initializer_range: f64,
    pub layer_norm_eps: f64,
    pub pad_token_id: Option<usize>,
    pub position_embedding_type: String,
    pub use_cache: bool,
    pub classifier_dropout: Option<f64>,
}

pub struct EmbeddingEngine {
    pub model_path: PathBuf,
    pub config: EmbeddingConfig,
    pub device: Device,
    pub max_seq_len: usize,
    /// True once we've confirmed `model.safetensors` is real, loadable tensor
    /// data (not a Git LFS pointer stub, not truncated, not corrupted).
    ///
    /// NOTE: this flag being `true` does NOT mean `embed()` below is using
    /// those weights yet — see the doc comment on `embed()`.
    weights_available: bool,
}

impl EmbeddingEngine {
    pub async fn new(device: Device) -> Result<Self> {
        let model_path = PathBuf::from("/root/Ragatha/ragatha-embedding-350M-8bit");

        println!("🧠 Initializing embedding engine...");
        println!("📂 Embedding model path: {:?}", model_path);
        println!("💻 Device: {:?}", device);

        let config_path = model_path.join("config.json");
        if !config_path.exists() {
            anyhow::bail!("Config file not found at {:?}", config_path);
        }

        let config_str = fs::read_to_string(&config_path).await?;
        let config: serde_json::Value = serde_json::from_str(&config_str)?;

        println!("📋 Embedding model config loaded");
        println!("🏗️ Architecture: {:?}", config["architectures"]);
        println!("📊 Hidden size: {:?}", config["hidden_size"]);

        let embed_config = EmbeddingConfig {
            vocab_size: config["vocab_size"].as_u64().unwrap_or(30522) as usize,
            hidden_size: config["hidden_size"].as_u64().unwrap_or(1024) as usize,
            num_hidden_layers: config["num_hidden_layers"].as_u64().unwrap_or(12) as usize,
            num_attention_heads: config["num_attention_heads"].as_u64().unwrap_or(16) as usize,
            intermediate_size: config["intermediate_size"].as_u64().unwrap_or(4096) as usize,
            hidden_act: config["hidden_act"].as_str().unwrap_or("gelu").to_string(),
            hidden_dropout_prob: config["hidden_dropout_prob"].as_f64().unwrap_or(0.1),
            max_position_embeddings: config["max_position_embeddings"].as_u64().unwrap_or(512) as usize,
            type_vocab_size: config["type_vocab_size"].as_u64().unwrap_or(2) as usize,
            initializer_range: config["initializer_range"].as_f64().unwrap_or(0.02),
            layer_norm_eps: config["layer_norm_eps"].as_f64().unwrap_or(1e-12),
            pad_token_id: config["pad_token_id"].as_u64().map(|v| v as usize),
            position_embedding_type: config["position_embedding_type"].as_str().unwrap_or("absolute").to_string(),
            use_cache: config["use_cache"].as_bool().unwrap_or(true),
            classifier_dropout: config["classifier_dropout"].as_f64(),
        };

        println!("✅ Config parsed");
        println!("📊 Model architecture: LFM2 Bidirectional (custom embedding)");

        // Check if weights file exists and is genuine safetensors data (not a
        // Git LFS pointer stub — what you get when a Git-LFS-backed model repo
        // is cloned without `git lfs pull`, or without git-lfs installed at
        // all: a ~130-byte text file instead of the multi-hundred-MB binary).
        let weights_path = model_path.join("model.safetensors");
        let mut weights_available = false;
        if weights_path.exists() {
            let metadata = std::fs::metadata(&weights_path)?;
            let file_size = metadata.len();
            println!("📦 Found weights file: {} bytes ({:.2} MB)", file_size, file_size as f64 / 1024.0 / 1024.0);

            match self::check_safetensors(&weights_path) {
                Ok(SafetensorsCheck::Valid) => {
                    println!("✅ Safetensors file appears valid");
                    // Try to load with VarBuilder
                    match unsafe { VarBuilder::from_mmaped_safetensors(&[weights_path.clone()], DType::F32, &device) } {
                        Ok(_vb) => {
                            weights_available = true;
                            println!("✅ Successfully loaded weights with VarBuilder");
                            println!("ℹ️  Note: those weights aren't actually used for embeddings yet.");
                            println!("   candle-transformers only ships the causal-LM LFM2 graph");
                            println!("   (candle_transformers::models::lfm2), not a bidirectional");
                            println!("   encoder forward pass, so there's no ready-made code path");
                            println!("   for this checkpoint's architecture. Still using the");
                            println!("   hash-based fallback embedding below until a real forward");
                            println!("   pass is written for it.");
                        }
                        Err(e) => {
                            println!("⚠️  VarBuilder load failed: {}", e);
                            println!("   Using fallback embedding (semantic search will be limited)");
                        }
                    }
                }
                Ok(SafetensorsCheck::LfsPointer) => {
                    println!("⚠️  {:?} is a Git LFS pointer stub, not real weights.", weights_path);
                    println!("   The actual tensor data was never downloaded. Fix with:");
                    println!("     cd {:?}", model_path);
                    println!("     git lfs install && git lfs pull");
                    println!("   or re-fetch the repo with:");
                    println!("     huggingface-cli download <repo-id> --local-dir {:?}", model_path);
                    println!("   Using fallback embedding (semantic search will be limited)");
                }
                Ok(SafetensorsCheck::Corrupted) => {
                    println!("⚠️  Safetensors file may be corrupted or incompatible");
                    println!("   Using fallback embedding (semantic search will be limited)");
                }
                Err(e) => {
                    println!("⚠️  Could not verify safetensors file: {}", e);
                    println!("   Using fallback embedding (semantic search will be limited)");
                }
            }
        } else {
            println!("⚠️  No weights file found at: {}", weights_path.display());
            println!("   Using fallback embedding (semantic search will be limited)");
        }

        println!("✅ Embedding engine initialized (fallback mode for LFM2)");

        Ok(Self {
            model_path,
            config: embed_config,
            device,
            max_seq_len: 512,
            weights_available,
        })
    }

    /// Produce an embedding for `text`.
    ///
    /// IMPORTANT: this always uses the hash-based bag-of-words approximation
    /// below, regardless of `self.weights_available`. Real LFM2 weights
    /// loading successfully only proves the safetensors file is intact — it
    /// doesn't mean there's a model graph wired up to run them through.
    /// candle-transformers 0.11 ships `candle_transformers::models::lfm2`,
    /// which implements the causal-LM (`Lfm2ForCausalLM`) graph only; this
    /// checkpoint's "Lfm2BidirectionalModel" architecture (non-causal
    /// attention, no `lm_head`, presumably mean- or CLS-pooled output) isn't
    /// one of candle's catalogued models, so there's nothing to call into
    /// yet. To wire up real embeddings: get this checkpoint's actual
    /// `config.json` and the tensor names inside its safetensors header
    /// (`python -c "from safetensors import safe_open; f=safe_open(path,
    /// 'pt'); print(list(f.keys()))"`), and implement a small non-causal
    /// forward pass reusing the building blocks in
    /// `candle_transformers::models::lfm2` (RmsNorm, the short-conv block,
    /// the attention block with the causal mask removed) followed by a
    /// pooling step over all token positions.
    pub async fn embed(&self, text: &str) -> Result<Vec<f32>> {
        // Simple but effective embedding using TF-IDF style
        let words: Vec<&str> = text.split_whitespace().collect();
        let mut embedding = vec![0.0; self.config.hidden_size];

        for word in words {
            let hash = word.chars().fold(0u64, |acc, c| acc ^ (c as u64));
            let index = (hash % self.config.hidden_size as u64) as usize;
            embedding[index] += 1.0;
        }

        // Normalize
        let norm: f32 = embedding.iter().map(|&x| x * x).sum::<f32>().sqrt();
        if norm > 0.0 {
            for val in &mut embedding { *val /= norm; }
        }

        Ok(embedding)
    }

    pub fn model_info(&self) -> String {
        format!(
            "LFM2 Embedding Model: {} ({} layers, {} hidden size) [{}]",
            self.model_path.display(),
            self.config.num_hidden_layers,
            self.config.hidden_size,
            if self.weights_available {
                "Weights present, fallback embedding still in use"
            } else {
                "Fallback Mode"
            }
        )
    }

    pub async fn verify_compatibility(&self, main_model_path: &Path) -> Result<bool> {
        let main_config_path = main_model_path.join("config.json");
        if !main_config_path.exists() { return Ok(false); }
        let config_str = fs::read_to_string(&main_config_path).await?;
        let config: serde_json::Value = serde_json::from_str(&config_str)?;
        let main_vocab = config["vocab_size"].as_u64().unwrap_or(0);
        let embed_vocab = self.config.vocab_size as u64;
        if main_vocab != embed_vocab {
            println!("⚠️  Vocabulary mismatch: Main={}, Embedding={}", main_vocab, embed_vocab);
            return Ok(false);
        }
        println!("✅ Models are compatible! Shared vocabulary size: {}", main_vocab);
        Ok(true)
    }
}

/// Result of inspecting a `model.safetensors` file before attempting to mmap
/// and parse it as safetensors.
enum SafetensorsCheck {
    Valid,
    LfsPointer,
    Corrupted,
}

// Helper function to check if a file is a valid safetensors file
fn check_safetensors(path: &Path) -> Result<SafetensorsCheck> {
    use std::io::Read;

    let metadata = std::fs::metadata(path)?;

    // A real safetensors file starts with an 8-byte little-endian header
    // length followed by a JSON header describing every tensor, so it can
    // never plausibly be a few hundred bytes long. Git LFS pointer stubs
    // (what you get from a `git clone` that never ran `git lfs pull`) are
    // small plain-text files that look like:
    //   version https://git-lfs.github.com/spec/v1
    //   oid sha256:<64 hex chars>
    //   size <byte count>
    // Check for that specific case first so the diagnosis is actionable
    // instead of "header size is a billion bytes, likely corrupted".
    if metadata.len() < 4096 {
        let content = std::fs::read_to_string(path).unwrap_or_default();
        if content.starts_with("version https://git-lfs.github.com/spec/v1") {
            return Ok(SafetensorsCheck::LfsPointer);
        }
        println!(
            "⚠️  Weights file is only {} bytes — far too small to be real model weights",
            metadata.len()
        );
        return Ok(SafetensorsCheck::Corrupted);
    }

    let file = std::fs::File::open(path)?;
    let mut reader = std::io::BufReader::new(file);

    // Read the first 8 bytes to check the header size
    let mut header_size_bytes = [0u8; 8];
    if let Err(e) = reader.read_exact(&mut header_size_bytes) {
        println!("⚠️  Could not read header size: {}", e);
        return Ok(SafetensorsCheck::Corrupted);
    }

    // Parse as little-endian u64
    let header_size = u64::from_le_bytes(header_size_bytes);
    println!("📊 Safetensors header size: {} bytes", header_size);

    // Check if header size is reasonable (should be less than 1MB for most models)
    if header_size > 1024 * 1024 * 10 {
        println!("⚠️  Header size {} is too large (likely corrupted)", header_size);
        return Ok(SafetensorsCheck::Corrupted);
    }

    // Try to read the header JSON
    let mut header_bytes = vec![0u8; header_size as usize];
    if let Err(e) = reader.read_exact(&mut header_bytes) {
        println!("⚠️  Could not read header: {}", e);
        return Ok(SafetensorsCheck::Corrupted);
    }

    // Try to parse as JSON
    let header_str = String::from_utf8_lossy(&header_bytes);
    if let Err(e) = serde_json::from_str::<serde_json::Value>(&header_str) {
        println!("⚠️  Header is not valid JSON: {}", e);
        return Ok(SafetensorsCheck::Corrupted);
    }

    Ok(SafetensorsCheck::Valid)
}

pub struct CachedEmbeddingEngine {
    pub engine: EmbeddingEngine,
    cache: std::collections::HashMap<String, Vec<f32>>,
    cache_size: usize,
}

impl CachedEmbeddingEngine {
    pub async fn new(device: Device) -> Result<Self> {
        let engine = EmbeddingEngine::new(device).await?;
        Ok(Self {
            engine,
            cache: std::collections::HashMap::new(),
            cache_size: 1000,
        })
    }

    pub async fn embed(&mut self, text: &str) -> Result<Vec<f32>> {
        if let Some(embedding) = self.cache.get(text) {
            return Ok(embedding.clone());
        }
        let embedding = self.engine.embed(text).await?;
        if self.cache.len() < self.cache_size {
            self.cache.insert(text.to_string(), embedding.clone());
        }
        Ok(embedding)
    }

    pub fn clear_cache(&mut self) {
        self.cache.clear();
    }

    pub fn info(&self) -> String {
        format!("{} Cache: {} entries", self.engine.model_info(), self.cache.len())
    }

    pub fn get_engine(&self) -> &EmbeddingEngine {
        &self.engine
    }
}
