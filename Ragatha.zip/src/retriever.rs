use anyhow::Result;
use crate::Document;
use std::collections::HashMap;

pub struct Retriever {
    index: HashMap<usize, Vec<f32>>,
    documents: Vec<Document>,
}

impl Retriever {
    pub fn new() -> Self {
        Self {
            index: HashMap::new(),
            documents: Vec::new(),
        }
    }
    
    pub async fn index_documents(&mut self, documents: &[Document]) -> Result<()> {
        self.documents.clear();
        self.index.clear();
        
        for (idx, doc) in documents.iter().enumerate() {
            if let Some(embedding) = &doc.embedding {
                self.index.insert(idx, embedding.clone());
                self.documents.push(doc.clone());
            }
        }
        
        Ok(())
    }
    
    pub async fn search(&self, query_embedding: Vec<f32>, top_k: usize) -> Result<Vec<Document>> {
        let mut similarities: Vec<(usize, f32)> = Vec::new();
        
        for (idx, doc_embedding) in &self.index {
            let similarity = self.cosine_similarity(&query_embedding, doc_embedding);
            similarities.push((*idx, similarity));
        }
        
        similarities.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        
        let mut results = Vec::new();
        for (idx, _) in similarities.into_iter().take(top_k) {
            if let Some(doc) = self.documents.get(idx) {
                results.push(doc.clone());
            }
        }
        
        Ok(results)
    }
    
    pub async fn clear(&mut self) -> Result<()> {
        self.documents.clear();
        self.index.clear();
        Ok(())
    }
    
    fn cosine_similarity(&self, a: &[f32], b: &[f32]) -> f32 {
        let dot_product: f32 = a.iter().zip(b.iter()).map(|(x, y)| x * y).sum();
        let norm_a: f32 = a.iter().map(|&x| x * x).sum::<f32>().sqrt();
        let norm_b: f32 = b.iter().map(|&x| x * x).sum::<f32>().sqrt();
        
        if norm_a == 0.0 || norm_b == 0.0 {
            return 0.0;
        }
        
        dot_product / (norm_a * norm_b)
    }
}
