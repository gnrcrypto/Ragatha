use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Document {
    pub content: String,
    pub source: String,
    pub source_type: DocumentSource,
    pub embedding: Option<Vec<f32>>,
    pub metadata: DocumentMetadata,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DocumentSource {
    Readme(String),
    Config(String),
    SourceDoc(String),
    SystemDoc(String),
    Online(String),
    LocalDoc(String),
    Memory,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DocumentMetadata {
    pub title: Option<String>,
    pub author: Option<String>,
    pub date: Option<String>,
    pub version: Option<String>,
    pub tags: Vec<String>,
}

impl Document {
    pub fn new(content: String, source_type: DocumentSource) -> Self {
        Self {
            content,
            source: source_type.to_string(),
            source_type,
            embedding: None,
            metadata: DocumentMetadata {
                title: None,
                author: None,
                date: None,
                version: None,
                tags: Vec::new(),
            },
        }
    }
    
    pub fn with_embedding(mut self, embedding: Vec<f32>) -> Self {
        self.embedding = Some(embedding);
        self
    }
}

impl std::fmt::Display for DocumentSource {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            DocumentSource::Readme(path) => write!(f, "README: {}", path),
            DocumentSource::Config(path) => write!(f, "Config: {}", path),
            DocumentSource::SourceDoc(path) => write!(f, "Source: {}", path),
            DocumentSource::SystemDoc(path) => write!(f, "System: {}", path),
            DocumentSource::Online(url) => write!(f, "Online: {}", url),
            DocumentSource::LocalDoc(path) => write!(f, "Local Doc: {}", path),
            DocumentSource::Memory => write!(f, "Memory"),
        }
    }
}
