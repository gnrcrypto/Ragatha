use anyhow::{Result};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::PathBuf;
use tokio::fs;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PersistentMemory {
    pub task_history: Vec<TaskRecord>,
    pub learned_patterns: Vec<Pattern>,
    pub error_knowledge: Vec<ErrorRecord>,
    pub document_cache: HashMap<String, String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskRecord {
    pub task_id: String,
    pub description: String,
    pub timestamp: String,
    pub operations_performed: Vec<String>,
    pub success: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Pattern {
    pub name: String,
    pub description: String,
    pub frequency: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ErrorRecord {
    pub error_type: String,
    pub context: String,
    pub solution: String,
    pub occurrences: u32,
}

impl PersistentMemory {
    pub async fn load() -> Result<Self> {
        let memory_path = PathBuf::from(".ragatha_memory.json");
        if memory_path.exists() {
            let content = fs::read_to_string(&memory_path).await?;
            let memory: PersistentMemory = serde_json::from_str(&content)?;
            println!("📖 Loaded memory: {} tasks, {} patterns", memory.task_history.len(), memory.learned_patterns.len());
            Ok(memory)
        } else {
            Ok(Self {
                task_history: Vec::new(),
                learned_patterns: Vec::new(),
                error_knowledge: Vec::new(),
                document_cache: HashMap::new(),
            })
        }
    }
    
    pub async fn load_state(&mut self) -> Result<()> {
        let memory = Self::load().await?;
        self.task_history = memory.task_history;
        self.learned_patterns = memory.learned_patterns;
        self.error_knowledge = memory.error_knowledge;
        self.document_cache = memory.document_cache;
        Ok(())
    }
    
    pub async fn save(&self) -> Result<()> {
        let content = serde_json::to_string_pretty(self)?;
        fs::write(".ragatha_memory.json", content).await?;
        Ok(())
    }
    
    pub async fn record_task(&mut self, task: TaskRecord) -> Result<()> {
        self.task_history.push(task);
        self.save().await?;
        Ok(())
    }
    
    pub async fn add_pattern(&mut self, pattern: Pattern) -> Result<()> {
        if let Some(existing) = self.learned_patterns.iter_mut().find(|p| p.name == pattern.name) {
            existing.frequency += 1;
        } else {
            self.learned_patterns.push(pattern);
        }
        self.save().await?;
        Ok(())
    }
    
    pub async fn record_error(&mut self, error: ErrorRecord) -> Result<()> {
        if let Some(existing) = self.error_knowledge.iter_mut().find(|e| e.error_type == error.error_type) {
            existing.occurrences += 1;
            if existing.solution != error.solution {
                existing.solution = format!("{}\nAlternative: {}", existing.solution, error.solution);
            }
        } else {
            self.error_knowledge.push(error);
        }
        self.save().await?;
        Ok(())
    }
}
