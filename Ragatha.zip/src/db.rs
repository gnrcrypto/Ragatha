//! Database layer for persistent knowledge storage.
//! Uses SQLite with a simple schema: files and embeddings.

use anyhow::Result;
use rusqlite::{Connection, params};
use std::path::Path;

/// Initialize the database, creating tables if they don't exist.
pub fn init_db(db_path: &Path) -> Result<Connection> {
    let conn = Connection::open(db_path)?;
    conn.execute(
        "CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY,
            path TEXT UNIQUE,
            content TEXT NOT NULL,
            last_indexed DATETIME DEFAULT CURRENT_TIMESTAMP
        )",
        [],
    )?;
    conn.execute(
        "CREATE TABLE IF NOT EXISTS embeddings (
            file_id INTEGER PRIMARY KEY REFERENCES files(id) ON DELETE CASCADE,
            embedding BLOB NOT NULL
        )",
        [],
    )?;
    // Optional: index for faster path lookups
    conn.execute("CREATE INDEX IF NOT EXISTS idx_path ON files(path)", [])?;
    Ok(conn)
}

/// Insert or replace a file and its embedding.
pub fn upsert_file(conn: &Connection, path: &str, content: &str, embedding: &[f32]) -> Result<i64> {
    // Insert or replace the file
    conn.execute(
        "INSERT OR REPLACE INTO files (path, content) VALUES (?1, ?2)",
        params![path, content],
    )?;
    let file_id = conn.last_insert_rowid();

    // Convert embedding to blob
    let blob: Vec<u8> = embedding
        .iter()
        .flat_map(|&v| v.to_le_bytes())
        .collect();

    conn.execute(
        "INSERT OR REPLACE INTO embeddings (file_id, embedding) VALUES (?1, ?2)",
        params![file_id, blob],
    )?;

    Ok(file_id)
}

/// Retrieve all file IDs, their full content, and embeddings as a blob.
pub fn get_all_files_with_embeddings(conn: &Connection) -> Result<Vec<(i64, String, Vec<f32>)>> {
    let mut stmt = conn.prepare(
        "SELECT f.id, f.content, e.embedding
         FROM files f
         JOIN embeddings e ON f.id = e.file_id"
    )?;
    let rows = stmt.query_map([], |row| {
        let id: i64 = row.get(0)?;
        let content: String = row.get(1)?;
        let blob: Vec<u8> = row.get(2)?;
        // Reconstruct f32 vector from blob
        let emb_vec: Vec<f32> = blob
            .chunks_exact(4)
            .map(|b| f32::from_le_bytes([b[0], b[1], b[2], b[3]]))
            .collect();
        Ok((id, content, emb_vec))
    })?;

    let mut result = Vec::new();
    for row in rows {
        result.push(row?);
    }
    Ok(result)
}

/// Retrieve a file by its ID.
pub fn get_file_by_id(conn: &Connection, id: i64) -> Result<Option<String>> {
    let mut stmt = conn.prepare("SELECT content FROM files WHERE id = ?1")?;
    let mut rows = stmt.query(params![id])?;
    if let Some(row) = rows.next()? {
        Ok(Some(row.get(0)?))
    } else {
        Ok(None)
    }
}

/// Clear all knowledge (for testing or reset).
pub fn clear_all(conn: &Connection) -> Result<()> {
    conn.execute("DELETE FROM embeddings", [])?;
    conn.execute("DELETE FROM files", [])?;
    Ok(())
}
