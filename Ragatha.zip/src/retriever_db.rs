//! GPU/CPU accelerated retriever backed by SQLite.

use anyhow::Result;
use candle_core::{Device, Tensor};
use ordered_float::OrderedFloat;
use std::collections::BinaryHeap;
use std::sync::Arc;
use rusqlite::Connection;
use candle_core::IndexOp;

pub struct DatabaseRetriever {
    conn: Arc<Connection>,
    gpu_embeddings: Option<Tensor>,
    file_ids: Vec<i64>,
    emb_dim: usize,
}

impl DatabaseRetriever {
    pub fn new(conn: Arc<Connection>) -> Self {
        Self {
            conn,
            gpu_embeddings: None,
            file_ids: Vec::new(),
            emb_dim: 0,
        }
    }

    pub fn load_embeddings(&mut self, device: &Device) -> Result<usize> {
        let (ids, _contents, all_embs) = self.fetch_all_embeddings()?;
        if all_embs.is_empty() {
            self.gpu_embeddings = None;
            self.file_ids = Vec::new();
            self.emb_dim = 0;
            return Ok(0);
        }

        let emb_dim = all_embs[0].len();
        self.emb_dim = emb_dim;

        let mut tensors = Vec::with_capacity(all_embs.len());
        for emb in all_embs {
            let t = Tensor::from_vec(emb, (emb_dim,), device)?;
            tensors.push(t);
        }
        let stacked = Tensor::stack(&tensors, 0)?;
        self.gpu_embeddings = Some(stacked);
        self.file_ids = ids;

        Ok(self.file_ids.len())
    }

    fn fetch_all_embeddings(&self) -> Result<(Vec<i64>, Vec<String>, Vec<Vec<f32>>)> {
        use super::db::get_all_files_with_embeddings;
        let rows = get_all_files_with_embeddings(&self.conn)?;
        let mut ids = Vec::with_capacity(rows.len());
        let mut contents = Vec::with_capacity(rows.len());
        let mut embs = Vec::with_capacity(rows.len());
        for (id, content, emb) in rows {
            ids.push(id);
            contents.push(content);
            embs.push(emb);
        }
        Ok((ids, contents, embs))
    }

    pub fn search(&self, query_emb: &[f32], k: usize) -> Result<Vec<(i64, String, f32)>> {
        if query_emb.len() != self.emb_dim && self.emb_dim != 0 {
            anyhow::bail!("Query embedding dimension mismatch");
        }

        if let Some(ref gpu_tensor) = self.gpu_embeddings {
            self.search_gpu(query_emb, k, gpu_tensor)
        } else {
            self.search_cpu(query_emb, k)
        }
    }

    // ========== MODIFIED search_gpu WITH MANUAL Top‑K ==========
    fn search_gpu(&self, query_emb: &[f32], k: usize, gpu_tensor: &Tensor) -> Result<Vec<(i64, String, f32)>> {
        let device = gpu_tensor.device();
        let query_tensor = Tensor::from_vec(query_emb.to_vec(), (1, self.emb_dim), &Device::Cpu)?
            .to_device(device)?;

        // similarities shape: (1, num_embeddings)
        let similarities = query_tensor.matmul(&gpu_tensor.t()?)?;

        // ---- Manual Top‑K implementation (no extra dependencies) ----
        // 1. Squeeze to 1‑dimensional tensor of length `num_embeddings`
        let sim_1d = similarities.squeeze(0)?;

        // 2. Get indices sorted in descending order (false = descending)
        let sorted_indices = sim_1d.arg_sort_last_dim(false)?;

        // 3. Take only the first `k` indices (slice along the only dimension)
        let top_indices = sorted_indices.i(..k)?;

        // 4. Gather the actual similarity values for those indices
        let top_values = sim_1d.index_select(&top_indices, 0)?;

        // Move results back to CPU and convert to Rust vectors
        let values_cpu = top_values.to_device(&Device::Cpu)?.to_vec1::<f32>()?;
        let indices_cpu = top_indices.to_device(&Device::Cpu)?.to_vec1::<u32>()?;

        // Build the final result list
        let mut results = Vec::with_capacity(k);
        for (i, &idx) in indices_cpu.iter().enumerate() {
            let file_id = self.file_ids[idx as usize];
            let content = super::db::get_file_by_id(&self.conn, file_id)?
                .unwrap_or_else(|| "Content not found".to_string());
            results.push((file_id, content, values_cpu[i]));
        }
        Ok(results)
    }

    fn search_cpu(&self, query_emb: &[f32], k: usize) -> Result<Vec<(i64, String, f32)>> {
        let (ids, contents, embs) = self.fetch_all_embeddings()?;
        if ids.is_empty() {
            return Ok(Vec::new());
        }

        let query_norm: f32 = query_emb.iter().map(|&x| x * x).sum::<f32>().sqrt();
        let mut heap = BinaryHeap::with_capacity(k);

        for idx in 0..ids.len() {
            let id = ids[idx];
            let content = &contents[idx];
            let emb = &embs[idx];
            let dot: f32 = query_emb.iter().zip(emb).map(|(a, b)| a * b).sum();
            let norm = (emb.iter().map(|&x| x * x).sum::<f32>()).sqrt();
            let similarity = dot / (query_norm * norm + 1e-8);

            if heap.len() < k {
                heap.push((OrderedFloat(similarity), id, content.clone()));
            } else if similarity > heap.peek().unwrap().0 .0 {
                heap.pop();
                heap.push((OrderedFloat(similarity), id, content.clone()));
            }
        }

        let mut results: Vec<_> = heap.into_sorted_vec();
        results.reverse();
        Ok(results
            .into_iter()
            .map(|(score, id, content)| (id, content, score.0))
            .collect())
    }

    pub fn num_loaded(&self) -> usize {
        self.file_ids.len()
    }
}
