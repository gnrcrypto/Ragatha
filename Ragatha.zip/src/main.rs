use anyhow::Result;
use std::path::Path;

/// Result of inspecting a `model.safetensors` file before attempting to mmap
/// and parse it as safetensors.
enum SafetensorsCheck {
    Valid,
    LfsPointer,
    Corrupted,
}

// Helper function to check if a file is a valid safetensors file
fn check_safetensors(path: &Path) -> Result<SafetensorsCheck> {
    use std::io::Read;

    let metadata = std::fs::metadata(path)?;

    if metadata.len() < 4096 {
        let content = std::fs::read_to_string(path).unwrap_or_default();
        if content.starts_with("version https://git-lfs.github.com/spec/v1") {
            return Ok(SafetensorsCheck::LfsPointer);
        }
        println!(
            "⚠️  Weights file is only {} bytes — far too small to be real model weights",
            metadata.len()
        );
        return Ok(SafetensorsCheck::Corrupted);
    }

    let file = std::fs::File::open(path)?;
    let mut reader = std::io::BufReader::new(file);

    let mut header_size_bytes = [0u8; 8];
    if let Err(e) = reader.read_exact(&mut header_size_bytes) {
        println!("⚠️  Could not read header size: {}", e);
        return Ok(SafetensorsCheck::Corrupted);
    }

    let header_size = u64::from_le_bytes(header_size_bytes);
    println!("📊 Safetensors header size: {} bytes", header_size);

    if header_size > 1024 * 1024 * 10 {
        println!("⚠️  Header size {} is too large (likely corrupted)", header_size);
        return Ok(SafetensorsCheck::Corrupted);
    }

    let mut header_bytes = vec![0u8; header_size as usize];
    if let Err(e) = reader.read_exact(&mut header_bytes) {
        println!("⚠️  Could not read header: {}", e);
        return Ok(SafetensorsCheck::Corrupted);
    }

    let header_str = String::from_utf8_lossy(&header_bytes);
    if let Err(e) = serde_json::from_str::<serde_json::Value>(&header_str) {
        println!("⚠️  Header is not valid JSON: {}", e);
        return Ok(SafetensorsCheck::Corrupted);
    }

    Ok(SafetensorsCheck::Valid)
}

fn check_weights_file(path: &Path) -> Result<()> {
    let metadata = std::fs::metadata(path)
        .map_err(|e| anyhow::anyhow!("Could not read metadata for {:?}: {}", path, e))?;

    if metadata.len() < 4096 {
        let content = std::fs::read_to_string(path).unwrap_or_default();
        if content.starts_with("version https://git-lfs.github.com/spec/v1") {
            anyhow::bail!(
                "{:?} is a Git LFS pointer stub ({} bytes), not the real model weights. \
                 The actual tensor data was never downloaded. Fix with:\n  cd {:?}\n  \
                 git lfs install && git lfs pull\nor re-fetch with:\n  \
                 huggingface-cli download <repo-id> --local-dir {:?}",
                path,
                metadata.len(),
                path.parent().unwrap_or(path),
                path.parent().unwrap_or(path),
            );
        }
        anyhow::bail!(
            "{:?} is only {} bytes — far too small to be real model weights. Re-download it.",
            path,
            metadata.len()
        );
    }

    Ok(())
}

fn main() -> Result<()> {
    // Exercise both functions against real temp files so this is an actual
    // runtime test, not just a type-check.
    let dir = std::env::temp_dir();

    let lfs_path = dir.join("stubcheck3_lfs_pointer.safetensors");
    std::fs::write(&lfs_path, "version https://git-lfs.github.com/spec/v1\noid sha256:abc\nsize 12345\n")?;
    match check_safetensors(&lfs_path)? {
        SafetensorsCheck::LfsPointer => println!("OK: detected LFS pointer via check_safetensors"),
        _ => panic!("FAIL: did not detect LFS pointer"),
    }
    match check_weights_file(&lfs_path) {
        Err(e) => println!("OK: check_weights_file bailed with: {}", e),
        Ok(()) => panic!("FAIL: check_weights_file did not bail on LFS pointer"),
    }

    let tiny_path = dir.join("stubcheck3_tiny.safetensors");
    std::fs::write(&tiny_path, "not lfs, just tiny")?;
    match check_safetensors(&tiny_path)? {
        SafetensorsCheck::Corrupted => println!("OK: detected too-small file via check_safetensors"),
        _ => panic!("FAIL: did not detect too-small file"),
    }

    let real_path = dir.join("stubcheck3_real.safetensors");
    let header = serde_json::json!({"__metadata__": {"format": "pt"}}).to_string();
    let header_bytes = header.as_bytes();
    let mut buf = Vec::new();
    buf.extend_from_slice(&(header_bytes.len() as u64).to_le_bytes());
    buf.extend_from_slice(header_bytes);
    buf.extend(std::iter::repeat(0u8).take(5000)); // pad past the 4096-byte small-file threshold
    std::fs::write(&real_path, &buf)?;
    match check_safetensors(&real_path)? {
        SafetensorsCheck::Valid => println!("OK: valid-looking safetensors header accepted"),
        _ => panic!("FAIL: valid header was rejected"),
    }
    check_weights_file(&real_path)?;
    println!("OK: check_weights_file accepted the valid-looking file");

    println!("ALL CHECKS PASSED");
    Ok(())
}
