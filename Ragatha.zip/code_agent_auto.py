#!/usr/bin/env python3
"""
Autonomous Code Agent - No confirmation, self-correcting.
Runs tool calls automatically and feeds results back to the model.
"""

import os
import sys
import json
import re
import glob
import random
import subprocess
import tempfile
from typing import List, Dict, Any
from llama_cpp import Llama

# ------------------------------------------------------------
# CONFIGURATION
MAX_ITERATIONS = 10          # Safety limit
TIMEOUT_SEC = 30             # Per tool execution

# ------------------------------------------------------------
# 1. Load GGUF model from current directory
gguf_files = glob.glob("/root/.cache/huggingface/hub/models--mradermacher--LFM2.5-1.2B-Thinking-SuperMinds-7x-Heretic-Uncensored-DISTILL-GGUF/snapshots/a6bf930bf6e44a65e21f90dbe2df288f3faa93c8/LFM2.5-1.2B-Thinking-SuperMinds-7x-Heretic-Uncensored-DISTILL.f16.gguf")
if not gguf_files:
    print("❌ No .gguf file found in current directory.")
    sys.exit(1)

MODEL_PATH = gguf_files[0]
print(f"📦 Loading model: {MODEL_PATH}")
llm = Llama(
    model_path=MODEL_PATH,
    n_ctx=8192,
    n_gpu_layers=-1,
    verbose=False
)

# ------------------------------------------------------------
# 2. Delimiter system (same as before, but deterministic for reproducibility)
DELIMITER_SETS = [
    {"open": "༒", "close": "༒", "mid": "࿇"},
    {"open": "꧁", "close": "꧂", "mid": "࿔"},
]
SUFFIX_POOL = ["龘", "靐"]

def generate_markers():
    s = DELIMITER_SETS[0]  # fixed for consistency
    suf1 = SUFFIX_POOL[0]
    suf2 = SUFFIX_POOL[1]
    return {
        "TC_START": f"{s['open']}{suf1}ᐅ",
        "TC_END": f"ᐊ{suf1}{s['close']}",
        "NAME_START": f"{s['mid']}▸",
        "NAME_END": f"◂{s['mid']}",
        "ARGS_START": f"{s['mid']}▹",
        "ARGS_END": f"◃{s['mid']}",
        "RESULT_START": f"{s['open']}{suf2}⟫",
        "RESULT_END": f"⟪{suf2}{s['close']}",
    }

MARKERS = generate_markers()

# ------------------------------------------------------------
# 3. Tool definitions (same)
TOOLS_DEFINITION = [
    {
        "type": "function",
        "function": {
            "name": "run_python",
            "description": "Execute Python code and return stdout/stderr.",
            "parameters": {
                "type": "object",
                "properties": {
                    "code": {"type": "string", "description": "Python code to execute"}
                },
                "required": ["code"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "run_bash",
            "description": "Run any bash command or script. Can create files, compile, run any language.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Bash command to execute"}
                },
                "required": ["command"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "compile_and_run_c",
            "description": "Write, compile (gcc), and run C code in one step.",
            "parameters": {
                "type": "object",
                "properties": {
                    "code": {"type": "string", "description": "C source code"}
                },
                "required": ["code"]
            }
        }
    }
]

def get_system_prompt():
    m = MARKERS
    tools_desc = "\n".join(
        f"- **{t['function']['name']}**: {t['function']['description']}\n  Parameters: {json.dumps(t['function']['parameters'])}"
        for t in TOOLS_DEFINITION
    )
    return f"""You are a code execution agent. You MUST NOT engage in conversation. Respond ONLY with tool calls using the exact format below. No extra text.

Available tools:
{tools_desc}

## How to call a tool (one or multiple):

{m['TC_START']}
{m['NAME_START']}tool_name{m['NAME_END']}
{m['ARGS_START']}{{"param": "value"}}{m['ARGS_END']}
{m['TC_END']}

## How tool results will appear:
When a tool is executed, you will see its output wrapped in:
{m['RESULT_START']}[tool_name]
output here
{m['RESULT_END']}

## Rules:
- No natural language.
- Output only tool call blocks.
- After seeing a result, decide if the task is complete. If not, output more tool calls.
- To indicate completion, output nothing (stop generating).

Now, given the user request, output the necessary tool call(s).""".strip()

# ------------------------------------------------------------
# 4. Tool executors
def execute_python(code: str) -> str:
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write(code)
        tmp_file = f.name
    try:
        result = subprocess.run(
            ['python3', tmp_file],
            capture_output=True,
            text=True,
            timeout=TIMEOUT_SEC
        )
        return (result.stdout + result.stderr).strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return f"Timeout after {TIMEOUT_SEC}s"
    finally:
        os.unlink(tmp_file)

def execute_bash(command: str) -> str:
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=TIMEOUT_SEC,
            executable='/bin/bash'
        )
        return (result.stdout + result.stderr).strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return f"Timeout after {TIMEOUT_SEC}s"

def execute_c(code: str) -> str:
    with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
        f.write(code)
        c_file = f.name
    bin_file = c_file.replace('.c', '')
    try:
        # Compile
        compile_proc = subprocess.run(
            ['gcc', c_file, '-o', bin_file],
            capture_output=True,
            text=True,
            timeout=10
        )
        if compile_proc.returncode != 0:
            return f"Compilation error:\n{compile_proc.stderr}"
        # Run
        run_proc = subprocess.run(
            [bin_file],
            capture_output=True,
            text=True,
            timeout=TIMEOUT_SEC
        )
        return (run_proc.stdout + run_proc.stderr).strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return f"Timeout after {TIMEOUT_SEC}s"
    finally:
        os.unlink(c_file)
        if os.path.exists(bin_file):
            os.unlink(bin_file)

# ------------------------------------------------------------
# 5. Parse tool calls from model output (returns list of (name, args_dict))
def parse_tool_calls(content: str) -> List[Dict[str, Any]]:
    m = MARKERS
    pattern = re.compile(
        re.escape(m['TC_START']) + r"\s*" +
        re.escape(m['NAME_START']) + r"(.*?)" + re.escape(m['NAME_END']) + r"\s*" +
        re.escape(m['ARGS_START']) + r"(.*?)" + re.escape(m['ARGS_END']) + r"\s*" +
        re.escape(m['TC_END']),
        re.DOTALL
    )
    tool_calls = []
    for match in pattern.finditer(content):
        name = match.group(1).strip()
        args_str = match.group(2).strip()
        try:
            args = json.loads(args_str)
        except:
            continue
        tool_calls.append({"name": name, "arguments": args})
    return tool_calls

# ------------------------------------------------------------
# 6. Build prompt from message history (for llama.cpp)
def format_prompt(messages: List[Dict[str, str]]) -> str:
    prompt = ""
    for msg in messages:
        role = msg["role"]
        content = msg["content"]
        if role == "system":
            prompt += f"<|system|>\n{content}\n"
        elif role == "user":
            prompt += f"<|user|>\n{content}\n"
        elif role == "assistant":
            prompt += f"<|assistant|>\n{content}\n"
        elif role == "tool":
            # tool results are injected as user messages with the RESULT markers
            prompt += f"<|user|>\n{content}\n"
    prompt += "<|assistant|>\n"
    return prompt

# ------------------------------------------------------------
# 7. Convert a tool call block into the delimiter format (for assistant message)
def tool_call_to_delimiter(name: str, args: dict) -> str:
    m = MARKERS
    return f"{m['TC_START']}\n{m['NAME_START']}{name}{m['NAME_END']}\n{m['ARGS_START']}{json.dumps(args)}{m['ARGS_END']}\n{m['TC_END']}"

# ------------------------------------------------------------
# 8. Execute a single tool call and return result as formatted string
def execute_tool(tool_name: str, args: dict) -> str:
    if tool_name == "run_python":
        output = execute_python(args.get("code", ""))
    elif tool_name == "run_bash":
        output = execute_bash(args.get("command", ""))
    elif tool_name == "compile_and_run_c":
        output = execute_c(args.get("code", ""))
    else:
        output = f"Unknown tool: {tool_name}"
    # Wrap result in the RESULT delimiters
    m = MARKERS
    return f"{m['RESULT_START']}[{tool_name}]\n{output}\n{m['RESULT_END']}"

# ------------------------------------------------------------
# 9. Main autonomous loop
def run_agent(user_prompt: str):
    # Initialize message history
    messages = [
        {"role": "system", "content": get_system_prompt()},
        {"role": "user", "content": user_prompt}
    ]

    iteration = 0
    while iteration < MAX_ITERATIONS:
        iteration += 1
        print(f"\n🔄 Iteration {iteration}/{MAX_ITERATIONS}")

        # Generate model response
        prompt_str = format_prompt(messages)
        response = llm(
            prompt_str,
            max_tokens=1024,
            temperature=0.2,
            top_p=0.9,
            stop=["<|user|>", "<|system|>"],
            echo=False
        )
        raw_output = response["choices"][0]["text"].strip()
        print(f"📝 Model raw output:\n{raw_output[:200]}{'...' if len(raw_output)>200 else ''}")

        # Parse tool calls
        tool_calls = parse_tool_calls(raw_output)
        if not tool_calls:
            print("✅ No tool calls generated – agent believes task is complete.")
            break

        # Build assistant message content (the raw output with delimiters)
        assistant_content = raw_output   # keep original delimiters for future context
        messages.append({"role": "assistant", "content": assistant_content})

        # Execute each tool call and collect results
        for tc in tool_calls:
            name = tc["name"]
            args = tc["arguments"]
            print(f"🔧 Executing {name}({json.dumps(args)})")
            result = execute_tool(name, args)
            print(f"📤 Output:\n{result[:300]}{'...' if len(result)>300 else ''}")
            # Append result as a user message (with RESULT delimiters)
            messages.append({"role": "user", "content": result})

        # Continue loop to let the model see results and decide next steps
        print("📨 Feeding results back to model...")

    if iteration >= MAX_ITERATIONS:
        print(f"⚠️ Reached maximum iterations ({MAX_ITERATIONS}). Stopping.")

def main():
    if len(sys.argv) > 1:
        user_prompt = ' '.join(sys.argv[1:])
    else:
        print("\n🤖 Autonomous Code Agent (no confirmation, self‑correcting)")
        user_prompt = input("💬 Enter your request: ").strip()
        if not user_prompt:
            print("No prompt provided.")
            sys.exit(0)

    print(f"\n🎯 Task: {user_prompt}\n")
    try:
        run_agent(user_prompt)
    except KeyboardInterrupt:
        print("\n🛑 Interrupted by user.")
    print("\n🏁 Agent finished.")

if __name__ == "__main__":
    main()
