#[cfg(test)]
mod tests {
    use super::*;
    use candle_core::Device;
    
    #[tokio::test]
    async fn test_rag_preparation() {
        let device = Device::Cpu;
        let mut rag = RagCore::new(device).await.unwrap();
        
        let project_dir = std::env::current_dir().unwrap();
        let task = "Build a capability bridge that reads files and makes network requests";
        
        rag.prepare_for_task(task, &project_dir).await.unwrap();
        
        let context = rag.get_context_for_operation("read file").await.unwrap();
        assert!(!context.is_empty());
        
        // Test retrieval
        let docs = rag.retrieve("how to read a file", 3).await.unwrap();
        assert!(!docs.is_empty());
    }
    
    #[tokio::test]
    async fn test_memory_persistence() {
        let memory = PersistentMemory::load().await.unwrap();
        assert!(memory.task_history.len() >= 0);
    }
}
