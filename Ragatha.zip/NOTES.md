# RAGATHA

--

## NOTES : 

--

1. --
** Ragatha 350M embedding version - requires asymmetric prompts **
- **this is extremely important**. The model was trained with "query: prefix" | "document: prefix", If you don’t use these, embedding quality drops significantly.

- We are going to load the embedding version directly onto the gpu, its a non conversational llm, great for rag use and has constant steady usage in vram that should be under 2gb

--

2. --
** Use openblas and cublas **
- We will be utilizing cuda specifically with the rag system. The entire 350M parameter embedding model can fit inside the 2gb worth of ram that the nvidia GeForce mx130 offers.
- We will utilize the openblas cpu acceleration that is added when utilizing openblas for all other opperations.
